# Kit Dobra

Recursos de marca e capturas de referência do aplicativo. O guia completo está
em [BRAND.md](BRAND.md); seus links de documentação abrem o repositório no GitHub.
Os SVGs de logo usam a fonte do sistema, sem lettering convertido em contornos.

- [Logo para fundo claro](assets/dobra-logo.svg)
- [Logo para fundo escuro](assets/dobra-logo-dark.svg)
- [Símbolo](assets/dobra-mark.svg)
- [Ícone SVG](assets/icon.svg) e [PNG](assets/icon.png)
- [Tela clara](previews/dobra-light.png) e [escura](previews/dobra-dark.png)

Código e recursos são distribuídos sob a [licença MIT](LICENSE).
